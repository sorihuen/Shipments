import { Request, Response } from 'express';
import { AuthController } from '../../controller/AuthController';
import { AuthService } from '../../services/security/AuthService';
import { UserRepository } from '../../repositories/UserRepository';
import { RegisterUserDto } from '../../dtos/RegisterUserDto';
import { validate } from 'class-validator';
import { plainToInstance } from 'class-transformer';

vi.mock('class-validator', async (importOriginal) => {
  const actual = await importOriginal();
  return { ...actual };
});

vi.mock('class-transformer', () => ({
  plainToInstance: vi.fn(),
}));

vi.mock('../../services/security/AuthService');
vi.mock('../../repositories/UserRepository');

describe('AuthController', () => {
  let authService: AuthService;
  let req: Request;
  let res: Response;

  beforeEach(() => {
    authService = new AuthService(new UserRepository()) as jest.Mocked<AuthService>;
    req = { body: {} } as Request;
    res = {
      status: vi.fn().mockReturnThis(),
      json: vi.fn(),
    } as unknown as Response;
  });

  describe('register', () => {
    it('should register a new user and return 201 status', async () => {
      const registerData = {
        username: 'testuser',
        email: 'test@example.com',
        password: 'password123',
        role: 'user',
      };

      req.body = registerData;
      (plainToInstance as vi.Mock).mockReturnValue(registerData);
      (validate as vi.Mock).mockResolvedValue([]);

      authService.register = vi.fn().mockResolvedValue({
        id: 1,
        username: 'testuser',
        email: 'test@example.com',
        role: 'user',
        passwordHash: 'hashedPassword',
        createdAt: new Date(),
        updatedAt: new Date(),
        isActive: true,
      });

      await AuthController.register(req, res);

      expect(plainToInstance).toHaveBeenCalledWith(RegisterUserDto, registerData);
      expect(validate).toHaveBeenCalledWith(registerData);
      expect(authService.register).toHaveBeenCalledWith(registerData);
      expect(res.status).toHaveBeenCalledWith(201);
      expect(res.json).toHaveBeenCalledWith({
        id: 1,
        username: 'testuser',
        email: 'test@example.com',
        role: 'user',
        passwordHash: 'hashedPassword',
        createdAt: expect.any(Date),
        updatedAt: expect.any(Date),
        isActive: true,
      });
    });

    it('should return 400 status if validation fails', async () => {
      const registerData = {
        username: 'testuser',
        email: 'test@example.com',
        password: 'password123',
        role: 'user',
      };

      req.body = registerData;
      (plainToInstance as vi.Mock).mockReturnValue(registerData);
      (validate as vi.Mock).mockResolvedValue([{ constraints: { isEmail: 'Invalid email' } }]);

      await AuthController.register(req, res);

      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith({ errors: ['Invalid email'] });
    });
  });
});
